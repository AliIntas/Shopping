<?php

$baglanti= mysqli_connect("localhost:3307","root","","e-shopping");

?>